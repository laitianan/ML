import org.apache.spark.ml.linalg.Vectors
import org.apache.spark.ml.feature._
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import org.apache.spark.ml.{Pipeline, PipelineModel, PipelineStage}
import org.apache.spark.ml.classification.RandomForestClassifier
import org.apache.spark.ml.classification.RandomForestClassificationModel
import org.jpmml.model.JAXBUtil
import org.jpmml.sparkml.PMMLBuilder
import org.dmg.pmml.PMML
import javax.xml.transform.stream.StreamResult
import java.io.FileOutputStream

import org.apache.spark.ml.linalg.DenseVector

import scala.collection.mutable.ArrayBuffer

object PMML_Save_Demo {
  def main(args: Array[String]): Unit = {

    println("666666")
    val spark = SparkSession.builder().master("local").appName("TestPmml").getOrCreate()

    val str2Int: Map[String, Double] = Map(
      "Iris-setosa" -> 0.0,
      "Iris-versicolor" -> 1.0,
      "Iris-virginica" -> 2.0
    )
    var str2double = (x: String) => str2Int(x)
    var myFun = udf(str2double)
    val data = spark.read.textFile("./iris1.txt").toDF()
      .withColumn("splitcol", split(col("value"), ","))
      .select(
        col("splitcol").getItem(0).as("sepal_length"),
        col("splitcol").getItem(1).as("sepal_width"),
        col("splitcol").getItem(2).as("petal_length"),
        col("splitcol").getItem(3).as("petal_width"),
        col("splitcol").getItem(4).as("label")
      )
      .withColumn("label", myFun(col("label")))
      .select(
        col("sepal_length").cast(DoubleType),
        col("sepal_width").cast(DoubleType),
        col("petal_length").cast(DoubleType),
        col("petal_width").cast(DoubleType),
        col("label").cast(DoubleType)
      )

    val data1 = data.na.drop()
    println("data: " + data1.count().toString)
    val schema = data1.schema
    println("data1 schema: " + schema)

    // merge multi-feature to vector features
    val features: Array[String] = Array("sepal_length", "sepal_width", "petal_length", "petal_width")
    val assembler: VectorAssembler = new VectorAssembler().setInputCols(features).setOutputCol("features")

    val rf: RandomForestClassifier = new RandomForestClassifier()
      .setLabelCol("label")
      .setFeaturesCol("features")
      .setMaxDepth(8)
      .setNumTrees(30)
      .setSeed(1234)
      .setMinInfoGain(0)
      .setMinInstancesPerNode(1)


    val pipeline = new Pipeline().setStages(Array(assembler,rf))

    val pipelineModel = pipeline.fit(data1)
    println("success fit......")
    val pmml = new PMMLBuilder(schema, pipelineModel).build()
    val targetFile = "./PMML/pipemodel.pmml"
    val fis: FileOutputStream = new FileOutputStream(targetFile)
    val fout: StreamResult = new StreamResult(fis)
    JAXBUtil.marshalPMML(pmml, fout)
    println("pmml success......")
  }
}