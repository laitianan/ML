import org.dmg.pmml.FieldName;
import org.dmg.pmml.PMML;
import org.jpmml.evaluator.*;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PMML_LoadDemo2 {
    private Evaluator loadPmml(){
        PMML pmml = new PMML();
        try{
            InputStream inputStream = new FileInputStream("./PMML/pipemodel.pmml");
            pmml = org.jpmml.model.PMMLUtil.unmarshal(inputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ModelEvaluatorFactory modelEvaluatorFactory = ModelEvaluatorFactory.newInstance();
        return modelEvaluatorFactory.newModelEvaluator(pmml);
    }
    private Object predict(Evaluator evaluator,double a, double b, double c, double d) {
        Map<String, Double> data = new HashMap<String, Double>();
        data.put("sepal_length", a);
        data.put("sepal_width", b);
        data.put("petal_length", c);
        data.put("petal_width", d);
        List<InputField> inputFields = evaluator.getInputFields();
        //过模型的原始特征，从画像中获取数据，作为模型输入
        Map<FieldName, FieldValue> arguments = new LinkedHashMap<FieldName, FieldValue>();
        for (InputField inputField : inputFields) {
            FieldName inputFieldName = inputField.getName();
            Object rawValue = data.get(inputFieldName.getValue());
            FieldValue inputFieldValue = inputField.prepare(rawValue);
            arguments.put(inputFieldName, inputFieldValue);
        }

        Map<FieldName, ?> results = evaluator.evaluate(arguments);

        List<TargetField> targetFields = evaluator.getTargetFields();
        TargetField targetField = targetFields.get(0);
        FieldName targetFieldName = targetField.getName();
        ProbabilityDistribution target = (ProbabilityDistribution) results.get(targetFieldName);
        System.out.println(a + " " + b + " " + c + " " + d + ":" + target);
        return target;
    }
    public static void main(String args[]){
        PMML_LoadDemo2 demo = new PMML_LoadDemo2();
        Evaluator model = demo.loadPmml();
        demo.predict(model,2,5,6,8);
        demo.predict(model,7,9,3,6);
        demo.predict(model,1,2,3,1);
        demo.predict(model,2,4,1,5);
    }
}